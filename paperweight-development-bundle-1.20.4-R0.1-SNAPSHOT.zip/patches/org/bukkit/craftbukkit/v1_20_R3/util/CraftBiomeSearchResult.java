package org.bukkit.craftbukkit.v1_20_R3.util;

import org.bukkit.Location;
import org.bukkit.block.Biome;
import org.bukkit.util.BiomeSearchResult;

public class CraftBiomeSearchResult implements BiomeSearchResult {

    private final Biome biome;
    private final Location location;

    public CraftBiomeSearchResult(Biome biome, Location location) {
        this.biome = biome;
        this.location = location;
    }

    public Biome getBiome() {
        return this.biome;
    }

    public Location getLocation() {
        return this.location;
    }
}
