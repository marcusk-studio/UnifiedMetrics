package com.destroystokyo.paper;

/**
 * @deprecated kept as a means to identify Paper in older plugins/PaperLib
 */
@Deprecated(forRemoval = true)
public class PaperConfig {
}
