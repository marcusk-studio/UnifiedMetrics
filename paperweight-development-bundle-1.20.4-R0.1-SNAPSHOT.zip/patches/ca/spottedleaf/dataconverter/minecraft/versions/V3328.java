package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;

public final class V3328 {

    private static final int VERSION = MCVersions.V23W06A + 2;

    public static void register() {
        // registers simple entity "minecraft:interaction"
    }
}
